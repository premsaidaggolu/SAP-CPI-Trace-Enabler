import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

Message processData(Message message) {

    def raw = message.getProperty("interfaceIds") as String

    if (raw == null || raw.trim().isEmpty()) {
        throw new IllegalArgumentException("Missing or empty property: interfaceIds")
    }


    def ids = raw.split(',')*.trim().findAll { it }


    def sw = new StringWriter()
    def xml = new MarkupBuilder(sw)

    xml.rows {
        ids.each { id ->
            row {
                interfaceId(id)
            }
        }
    }

    message.setBody(sw.toString())
    return message
}
